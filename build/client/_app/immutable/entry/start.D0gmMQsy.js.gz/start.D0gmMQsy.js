import{l as o,e as r}from"../chunks/Co0R7JPe.js";export{o as load_css,r as start};
