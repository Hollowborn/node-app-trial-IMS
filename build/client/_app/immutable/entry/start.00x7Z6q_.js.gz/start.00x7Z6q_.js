import{l as o,e as r}from"../chunks/DiJvn89z.js";export{o as load_css,r as start};
