import{Z as a}from"./VrzbJYtp.js";a();
