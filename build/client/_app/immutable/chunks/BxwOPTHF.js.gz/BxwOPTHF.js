import{i as c,j as r,k as i,E as s,l as h,m,o as p}from"./CSgM7ggg.js";function l(o,t,f){r&&i();var n=o,a,e;c(()=>{a!==(a=t())&&(e&&(m(e),e=null),a&&(e=h(()=>f(n,a))))},s),r&&(n=p)}export{l as c};
