import{g as N,a as l,c as x}from"./Do_-mL-j.js";import{p as y,d as z,s as S,c as C,h as I,r as j,f as A,g as s,u as B,ae as q}from"./CSgM7ggg.js";import{a as h,b as D}from"./eOTtUvit.js";import{e as E,i as F}from"./BveS6AeT.js";import{e as G}from"./Cj5OlSWR.js";import{p as t,r as H}from"./DFkGWr6I.js";/**
 * @license @lucide/svelte v0.515.0 - ISC
 *
 * ISC License
 * 
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 * 
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 */const J={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};var K=N("<svg><!><!></svg>");function U(m,e){y(e,!0);const u=t(e,"color",3,"currentColor"),r=t(e,"size",3,24),i=t(e,"strokeWidth",3,2),f=t(e,"absoluteStrokeWidth",3,!1),g=t(e,"iconNode",19,()=>[]),v=H(e,["$$slots","$$events","$$legacy","name","color","size","strokeWidth","absoluteStrokeWidth","iconNode","children"]);var o=K();h(o,a=>({...J,...v,width:r(),height:r(),stroke:u(),"stroke-width":a,class:["lucide-icon lucide",e.name&&`lucide-${e.name}`,e.class]}),[()=>f()?Number(i())*24/Number(r()):i()]);var n=C(o);E(n,17,g,F,(a,b)=>{var d=B(()=>q(s(b),2));let w=()=>s(d)[0],_=()=>s(d)[1];var c=x(),W=A(c);G(W,w,!0,(p,L)=>{h(p,()=>({..._()}))}),l(a,c)});var k=S(n);D(k,()=>e.children??I),j(o),l(m,o),z()}export{U as I};
