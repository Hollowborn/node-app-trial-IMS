import{$ as a}from"./BdQXYw_T.js";a();
