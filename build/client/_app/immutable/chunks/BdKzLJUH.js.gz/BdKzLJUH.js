import{w as t}from"./CSgM7ggg.js";const a={id:0,username:"",display_name:"",profileImage:null,role:"feeds",isAuthenticated:!1},s=t(a);function n(e){s.update(r=>({...r,...e}))}export{s as c,n as u};
